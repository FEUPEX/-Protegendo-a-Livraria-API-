# Livraria API — Segurança com BCrypt, JWT e RBAC

API RESTful de Livros e Autores (Node.js + Express, Clean Architecture) com:

- **BCrypt** (salt + work factor 10) para armazenar senhas
- **JWT stateless** (`Authorization: Bearer <token>`, expira em 2h, HS256)
- **RBAC** via middlewares (`autenticarToken` e `exigirRole`)

## Como executar

```bash
npm install
node server.js          # http://localhost:3000
```

Depois abra o `index.html` com o Live Server do VS Code (ou `py -m http.server 8080` e acesse http://localhost:8080).

> Opcional: defina `JWT_SECRET` como variável de ambiente. Sem ela, usa-se um segredo de desenvolvimento.

## Credenciais de teste

| Perfil | E-mail | Senha |
|---|---|---|
| ADMIN | admin@livraria.com | admin123 |
| USER | leitor@gmail.com | leitor123 |

Se você já tinha um `database.txt` da versão sem segurança, ele é corrigido automaticamente ao iniciar (ou apague o arquivo para recriá-lo).

## Matriz de permissões

| Método | Rota | Acesso | Sucesso | Falha |
|---|---|---|---|---|
| GET | `/api/v1/livros` | Público | 200 | — |
| GET | `/api/v1/livros/:id` | Público | 200 | — |
| POST | `/api/v1/auth/register` | Público (sempre cria USER) | 201 | 400 / 409 |
| POST | `/api/v1/auth/login` | Público | 200 | 401 |
| POST | `/api/v1/livros/:id/comentarios` | USER ou ADMIN | 201 | 401 |
| POST | `/api/v1/autores` | Somente ADMIN | 201 | 401 / 403 |
| POST | `/api/v1/livros` | Somente ADMIN | 201 | 401 / 403 |

## O que foi implementado

| Arquivo | Alteração |
|---|---|
| `services/AuthService.js` | Hash com `bcrypt.hash`, validação com `bcrypt.compare`, emissão do JWT; registro público força `role = USER` |
| `middlewares/authMiddleware.js` | `jwt.verify` real (401 para token ausente/inválido/expirado) e `exigirRole(...roles)` (403) |
| `config/auth.js` | Segredo, expiração, algoritmo e salt rounds em um só lugar |
| `repositories/LivrariaRepository.js` | Seed com hashes BCrypt reais de `admin123` e `leitor123` |
| `index.html` | Cadastro de autor (ADMIN), correção de `autor_nome` nos comentários, escape de HTML (XSS) |

## Exemplos com curl

```bash
# Login
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@livraria.com","senha":"admin123"}'

# Cadastrar autor (ADMIN)
curl -X POST http://localhost:3000/api/v1/autores \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{"nome":"Clarice Lispector","nacionalidade":"Brasileira"}'
```
