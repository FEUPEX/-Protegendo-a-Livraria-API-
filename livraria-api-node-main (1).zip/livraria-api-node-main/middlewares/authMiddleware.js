const jwt = require('jsonwebtoken');
const { JWT_SECRET, JWT_ALGORITHM } = require('../config/auth');

// Autenticação (AuthN): valida presença e integridade do token Bearer
function autenticarToken(req, res, next) {
  const authHeader = req.headers['authorization'] || '';
  const [esquema, token] = authHeader.split(' ');

  if (!token || esquema !== 'Bearer') {
    return res.status(401).json({ erro: "Acesso negado: token de autenticação não fornecido." });
  }

  jwt.verify(token, JWT_SECRET, { algorithms: [JWT_ALGORITHM] }, (err, usuarioDecodificado) => {
    if (err) {
      return res.status(401).json({ erro: "Token inválido, corrompido ou expirado." });
    }
    // Injeta o usuário autenticado na requisição para os controllers
    req.usuario = usuarioDecodificado;
    next();
  });
}

// Autorização (AuthZ / RBAC): aceita um ou mais perfis, ex.: exigirRole('ADMIN')
function exigirRole(...rolesPermitidas) {
  return (req, res, next) => {
    if (!req.usuario || !rolesPermitidas.includes(req.usuario.role)) {
      return res.status(403).json({
        erro: `Acesso proibido: privilégio de ${rolesPermitidas.join(' ou ')} exigido para esta operação.`
      });
    }
    next();
  };
}

module.exports = { autenticarToken, exigirRole };
