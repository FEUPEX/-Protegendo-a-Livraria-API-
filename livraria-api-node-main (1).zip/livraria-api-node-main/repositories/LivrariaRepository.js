const fs = require('fs');
const path = require('path');

// Hash de exemplo (inválido) que vinha no seed original; é substituído automaticamente
// em bancos database.txt criados antes da implementação do BCrypt.
const HASH_SEED_ANTIGO = '$2b$10$9v3m0C1O6mK9BqV3j0Xg9.1fG/3zR1i5e.7F6o4D1u1G2H3J4K5L6';

class LivrariaRepository {
  constructor() {
    // Garante que o arquivo fique na raiz do projeto (onde o server.js roda)
    this.dbPath = path.resolve(process.cwd(), 'database.txt');
    this._garantirArquivoInicial();
    this._migrarHashesSeed();
  }

  _obterDadosPadrao() {
    return {
      usuarios: [
        { id: 1, nome: "Admin", email: "admin@livraria.com", senha_hash: "$2b$10$vZN6fMl8OjaYOWofWnLaY.ufgyVl.631PURuraKJXBfWqIIk/GSBa", role: "ADMIN" },
        { id: 2, nome: "Leitor", email: "leitor@gmail.com", senha_hash: "$2b$10$4VibBIsb5cipOAUdMvmjTuFj7.BkYUOR6lzWyIRf58cnASfT9byTK", role: "USER" }
      ],
      autores: [
        { id: 1, nome: "Machado de Assis", nacionalidade: "Brasileiro" }
      ],
      livros: [
        {
          id: 1,
          titulo: "Dom Casmurro",
          ano: 1899,
          autor_id: 1,
          comentarios: [
            { id: 1, autor_nome: "Leitor", texto: "Clássico indispensável." }
          ]
        }
      ]
    };
  }

  _garantirArquivoInicial() {
    try {
      if (!fs.existsSync(this.dbPath)) {
        this.salvar(this._obterDadosPadrao());
      } else {
        const conteudo = fs.readFileSync(this.dbPath, 'utf-8').trim();
        if (!conteudo) {
          this.salvar(this._obterDadosPadrao());
        }
      }
    } catch (err) {
      console.error("Erro ao inicializar database.txt:", err);
    }
  }

  _migrarHashesSeed() {
    let db;
    try {
      db = JSON.parse(fs.readFileSync(this.dbPath, 'utf-8'));
    } catch (e) {
      return;
    }
    const padrao = this._obterDadosPadrao().usuarios;
    let alterado = false;
    for (const usuario of db.usuarios || []) {
      if (usuario.senha_hash === HASH_SEED_ANTIGO) {
        const seed = padrao.find(u => u.email === usuario.email);
        if (seed) {
          usuario.senha_hash = seed.senha_hash;
          alterado = true;
        }
      }
    }
    if (alterado) this.salvar(db);
  }

  carregar() {
    try {
      this._garantirArquivoInicial();
      const rawData = fs.readFileSync(this.dbPath, 'utf-8');
      return JSON.parse(rawData);
    } catch (e) {
      return this._obterDadosPadrao();
    }
  }

  salvar(dados) {
    fs.writeFileSync(this.dbPath, JSON.stringify(dados, null, 2), 'utf-8');
  }

  // Métodos de Usuários
  buscarUsuarioPorEmail(email) {
    const db = this.carregar();
    return db.usuarios.find(u => u.email === email) || null;
  }

  salvarUsuario(usuario) {
    const db = this.carregar();
    const novoUsuario = { id: Date.now(), ...usuario };
    db.usuarios.push(novoUsuario);
    this.salvar(db);
    return novoUsuario;
  }

  // Métodos de Autores
  listarAutores() {
    return this.carregar().autores || [];
  }

  buscarAutorPorId(id) {
    return (this.carregar().autores || []).find(a => a.id === Number(id)) || null;
  }

  salvarAutor(autor) {
    const db = this.carregar();
    const novoAutor = { id: Date.now(), ...autor };
    db.autores.push(novoAutor);
    this.salvar(db);
    return novoAutor;
  }

  // Métodos de Livros
  listarLivros() {
    return this.carregar().livros || [];
  }

  buscarLivroPorId(id) {
    return (this.carregar().livros || []).find(l => l.id === Number(id)) || null;
  }

  salvarLivro(livro) {
    const db = this.carregar();
    const novoLivro = { id: Date.now(), ...livro, comentarios: [] };
    db.livros.push(novoLivro);
    this.salvar(db);
    return novoLivro;
  }

  adicionarComentario(livroId, comentario) {
    const db = this.carregar();
    const livro = db.livros.find(l => l.id === Number(livroId));
    if (!livro) return null;

    if (!livro.comentarios) livro.comentarios = [];

    const novoComentario = { id: Date.now(), ...comentario };
    livro.comentarios.push(novoComentario);
    this.salvar(db);
    return novoComentario;
  }
}

module.exports = new LivrariaRepository();