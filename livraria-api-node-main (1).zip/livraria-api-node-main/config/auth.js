// Configurações compartilhadas de autenticação (JWT + BCrypt)
// Em produção, defina JWT_SECRET via variável de ambiente (nunca versione o segredo real).
module.exports = {
  JWT_SECRET: process.env.JWT_SECRET || "chave_super_secreta_livraria_2026",
  JWT_EXPIRES_IN: '2h',
  JWT_ALGORITHM: 'HS256',
  SALT_ROUNDS: 10
};
