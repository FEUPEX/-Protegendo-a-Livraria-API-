const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const repository = require('../repositories/LivrariaRepository');
const { JWT_SECRET, JWT_EXPIRES_IN, JWT_ALGORITHM, SALT_ROUNDS } = require('../config/auth');

// Hash descartável usado para equalizar o tempo de resposta quando o e-mail não existe
// (evita enumeração de usuários por análise de tempo).
const HASH_DUMMY = bcrypt.hashSync('senha-descartavel', SALT_ROUNDS);

const normalizarEmail = (email) => String(email).trim().toLowerCase();

class AuthService {
  async registrar({ nome, email, senha }) {
    if (!nome || !email || !senha) {
      throw { status: 400, message: "Campos obrigatórios ausentes: nome, email ou senha." };
    }
    if (typeof nome !== 'string' || typeof email !== 'string' || typeof senha !== 'string') {
      throw { status: 400, message: "Nome, e-mail e senha devem ser textos." };
    }

    const emailNormalizado = normalizarEmail(email);

    const usuarioExistente = repository.buscarUsuarioPorEmail(emailNormalizado);
    if (usuarioExistente) {
      throw { status: 409, message: "E-mail já cadastrado no sistema." };
    }

    // 1. Hash seguro com salt embutido (BCrypt)
    const senha_hash = await bcrypt.hash(senha, SALT_ROUNDS);

    // O perfil NÃO é aceito do cliente: o cadastro público sempre cria USER.
    // Contas ADMIN só existem via seed/banco, evitando escalonamento de privilégio.
    const novoUsuario = repository.salvarUsuario({
      nome: nome.trim(),
      email: emailNormalizado,
      senha_hash,
      role: "USER"
    });

    const { senha_hash: _, ...usuarioRetorno } = novoUsuario;
    return usuarioRetorno;
  }

  async login({ email, senha }) {
    if (!email || !senha) {
      throw { status: 400, message: "E-mail e senha são obrigatórios." };
    }
    if (typeof email !== 'string' || typeof senha !== 'string') {
      throw { status: 400, message: "E-mail e senha devem ser textos." };
    }

    // 1. Busca o usuário pelo e-mail
    const usuario = repository.buscarUsuarioPorEmail(normalizarEmail(email));

    // 2. Validação da senha com bcrypt.compare (sempre executa, mesmo sem usuário)
    const senhaValida = await bcrypt.compare(senha, usuario ? usuario.senha_hash : HASH_DUMMY);
    if (!usuario || !senhaValida) {
      throw { status: 401, message: "Credenciais inválidas." };
    }

    // 3. Emissão do token JWT assinado (stateless)
    const payload = {
      sub: String(usuario.id),
      nome: usuario.nome,
      role: usuario.role
    };

    const token = jwt.sign(payload, JWT_SECRET, {
      algorithm: JWT_ALGORITHM,
      expiresIn: JWT_EXPIRES_IN
    });

    return {
      usuario: { id: usuario.id, nome: usuario.nome, role: usuario.role },
      token
    };
  }
}

module.exports = new AuthService();
